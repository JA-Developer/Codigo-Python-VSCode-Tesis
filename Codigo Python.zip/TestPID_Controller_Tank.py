import numpy as np
import matplotlib.pyplot as plt
import Con_AHN
import PID
import Controller_Client
import Reference_Model
import time

print("CONTROLER")

Client = Controller_Client.ControllerClient('localhost', 10000)

#Crear controlador PID
Controller = PID.PID_Controller(0.12, 0.1, 0.1)

#Crear redes artificiales de hidrocarburos

Max_Kp = 5
Max_Ki = 5
Max_Kd = 5

Max_U = 100
Min_U = 0

#Crear redes artificiales de hidrocarburos
RKp = Con_AHN.AHN_Compound(5, 6, [[0, 200], [0, 200], [0, 200], [0, 200], [2*Min_U, 2*Max_U]], [-Max_Kp, Max_Kp])
RKi = Con_AHN.AHN_Compound(5, 6, [[0, 200], [0, 200], [0, 200], [0, 200], [2*Min_U, 2*Max_U]], [-Max_Ki, Max_Ki])
RKd = Con_AHN.AHN_Compound(5, 6, [[0, 200], [0, 200], [0, 200], [0, 200], [2*Min_U, 2*Max_U]], [-Max_Kd, Max_Kd])

#Crear emulador de la planta

Emulador = Con_AHN.AHN_Compound(6, 6, [[0, 200], [0, 200], [0, 200], [0, 200], [0, 200], [0, 200], [0, 200]], [0, 200])

#Crear modelo de referencia

RefM = Reference_Model.ReferenceModel(0.1, 1, 100, 0.1)

#Proceso de control

ModelRefError = 0
Error = 0
UCurrent = 0
Ref = 1
Jacobiano = 1

Y_string = ""
PastValues = np.zeros(3)
PastUValues = np.zeros(3)

Xplot = np.arange(60000)
Yplot = np.zeros(60000)

for t in range(0, 30000):
    
    Ref = 60
    
    #Solicitar salida de la planta

    Client.sendString("getY")

    #Esperar respuesta de la planta

    Y_string = Client.getString()

    #Obtener salida de la planta

    Y = float(Y_string)
    Yplot[t] = Y

    print("Periodo: " + str(t) + ", Salida: " + str(Y) + ", Kp: " + str(np.abs(Controller.Kp)) + ", Ki: " + str(np.abs(Controller.Ki)) + ", Kd: " + str(np.abs(Controller.Kd)))

    #Calcular salida de la señal de referencia

    Ref_Output = RefM.get_output_from_last_values(Ref, Ref, PastValues[0], PastValues[1])
    
    #Calcular error con respecto al modelo de referencia

    ModelRefError = Ref_Output - Y

    #Entrenar emulador

    X_Train_Emulador = [PastValues[0], PastValues[1], PastValues[2], PastUValues[0], PastUValues[1], PastUValues[2]]
    
    Noise = np.random.rand(6)*2 - 1

    output = Emulador.evaluate(X_Train_Emulador)
    Emulador.train_step_with_desired_output(X_Train_Emulador + Noise, output, Y, 0.00001, 0.00000001)

    #Verificar si se necesita entrenamiento

    Quad_Error = np.square(Ref_Output - Y)
    #print(Quad_Error)    
    if(t > 0 and True):
        if(Quad_Error > 0.01):
            
            Input = [Ref, Y, PastValues[0], PastValues[1], UCurrent]

            #Calcular Jacobiano

            X_Emulador = [Y, PastValues[0], PastValues[1], UCurrent, PastUValues[0], PastUValues[1]]
            NextY = Emulador.evaluate(X_Emulador)

            dU = UCurrent - PastUValues[0]
            dY = NextY - Y
            #dY = Y - PastValues[0]

            if(dU != 0):
                Jacobiano = dY/dU

            #Entrenar redes de hidrocarburos

            Grad_Kp = ModelRefError*Jacobiano*np.sign(Controller.Kp)*Controller.D_U_Kp()
            Grad_Ki = ModelRefError*Jacobiano*np.sign(Controller.Ki)*Controller.D_U_Ki()
            Grad_Kd = ModelRefError*Jacobiano*np.sign(Controller.Kd)*Controller.D_U_Kd()

            if(not (Grad_Kp < 0 and np.abs(Controller.Kp) >= Max_Kp)):
                RKp.train_step_with_derivate(Input, Grad_Kp, 0.00001, 1)

            if(not(Grad_Ki < 0 and np.abs(Controller.Ki) >= Max_Ki)):
                RKi.train_step_with_derivate(Input, Grad_Ki, 0.00001, 1)

            if(not(Grad_Kd < 0 and np.abs(Controller.Kd) >= Max_Kd)):
                RKd.train_step_with_derivate(Input, Grad_Kd, 0.00001, 1)

            #Actualizar valores PID
            
            Controller.Kp = RKp.evaluate(Input)
            Controller.Ki = RKi.evaluate(Input)
            Controller.Kd = RKd.evaluate(Input)

            #Asegurarse de que los valores PID esté dentro del rango permitido

            if(Controller.Kp > Max_Kp):
                Controller.Kp = Max_Kp
            if(Controller.Kp < -Max_Kp):
                Controller.Kp = -Max_Kp

            if(Controller.Ki > Max_Ki):
                Controller.Ki = Max_Ki
            if(Controller.Ki < -Max_Ki):
                Controller.Ki = -Max_Ki

            if(Controller.Kd > Max_Kd):
                Controller.Kd = Max_Kd
            if(Controller.Kd < -Max_Kd):
                Controller.Kd = -Max_Kd
    
    #Calcular error

    Error = Ref - Y

    #Obtener señal de control

    UCurrent += Controller.PID_Delta_U(Error)

    if(UCurrent > Max_U):
        UCurrent = Max_U
    if(UCurrent < Min_U):
        UCurrent = Min_U
    
    Client.sendString(UCurrent)
    
    #Actualizar valores pasados

    PastValues[2] = PastValues[1]
    PastValues[1] = PastValues[0]
    PastValues[0] = Y

    PastUValues[2] = PastUValues[1]
    PastUValues[1] = PastUValues[0]
    PastUValues[0] = UCurrent

plt.plot(Xplot, Yplot)
plt.show()