import numpy as np

def transition_function(x):
  return 0.5 + np.tanh(30*x)/2

def normalizar(X, Ranges):
  #Normalizar entrada

  XNorm = np.zeros(len(X))

  for i_x_norm in range(len(XNorm)):
    XNorm[i_x_norm] = (2*X[i_x_norm] - Ranges[i_x_norm][1] - Ranges[i_x_norm][0])/(Ranges[i_x_norm][1] - Ranges[i_x_norm][0])

  return XNorm

def inv_normalizar(XNorm, Ranges):
  #Normalizar entrada

  XNotNorm = np.zeros(len(XNorm))

  for i_x_not_norm in range(len(XNotNorm)):
    XNotNorm[i_x_not_norm] = ((Ranges[i_x_not_norm][1] - Ranges[i_x_not_norm][0])*XNorm[i_x_not_norm] + Ranges[i_x_not_norm][1] + Ranges[i_x_not_norm][0])/2

  return XNotNorm