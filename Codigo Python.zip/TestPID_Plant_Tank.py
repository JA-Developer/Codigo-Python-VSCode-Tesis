import numpy as np
import time
import Con_AHN
import Plant_Server

print("Tank")

#Crear servidor de planta para comunicación TCP/IP
Srvr = Plant_Server.PlantServer('localhost', 10000)
Srvr.listen()

#Planta a controlar

T = 0.1

C = 280

H1 = 0
H2 = 0

UCurrent = 100
K1 = 30
K2 = 30

A1 = 289
A2 = 144

t = 0

while True:

    t = t + 0.1

    if(t>5000):
        K2 = 10

    Q1 = UCurrent*C/100

    Q2 = K2 * np.sqrt(H2)

    Q12 = K1 * np.sqrt(np.abs(H1 - H2))

    H1 += (Q1 - Q2)/A1
    
    if(H1 < 0):
        H1 = 0


    H2 += (Q12 - Q2)/A2

    if(H2 < 0):
        H2 = 0

    print(str(UCurrent) + ", " + str(H2))

    Received = Srvr.getString(0)
    if(Received == ""):
        pass
    elif(Received == "getY"):
        Srvr.sendString(H2, 0)
    else:
        UCurrent = float(Received)
        if(UCurrent >= 100):
            UCurrent = 100