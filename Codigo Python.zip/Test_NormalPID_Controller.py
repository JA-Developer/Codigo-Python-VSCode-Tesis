import numpy as np
import matplotlib.pyplot as plt
import Con_AHN
import PID
import Controller_Client
import Reference_Model

print("CONTROLER")

Client = Controller_Client.ControllerClient('localhost', 10000)

#Crear controlador PID
Controller = PID.PID_Controller(0.12, 0.1, 0.1)

Error = 0
UCurrent = 0
Ref = 1

Y_string = ""
PastValues = np.zeros(3)
PastU = 0

Xplot = np.arange(10000)
Yplot = np.zeros(10000)

for t in range(0, 10000):
    
    if(t > 8000):
        Ref = 6
    elif(t > 7000):
        Ref = -6
    elif(t > 6000):
        Ref = -3
    elif(t > 5000):
        Ref = 4
    elif(t > 4000):
        Ref = 5
    elif(t > 3000):
        Ref = 4.5
    elif(t > 2000):
        Ref = 6
    elif(t > 1000):
        Ref = 5
    else:
        Ref = 6


    #Calcular error

    Error = Ref - PastValues[0]

    #Obtener señal de control

    UCurrent += Controller.PID_Delta_U(Error)

    #Solicitar salida de la planta

    Client.sendString("getY")

    #Esperar respuesta de la planta

    Y_string = Client.getString()

    #Obtener salida de la planta

    Y = float(Y_string)
    Yplot[t] = Y

    print("Periodo: " + str(t) + ", Salida: " + str(Y) + ", Kp: " + str(np.abs(Controller.Kp)) + ", Ki: " + str(np.abs(Controller.Ki)) + ", Kd: " + str(np.abs(Controller.Kd)))
    
    Client.sendString(UCurrent)
    
    #Actualizar valores pasados

    PastValues[2] = PastValues[1]
    PastValues[1] = PastValues[0]
    PastValues[0] = Y
    PastU = UCurrent

plt.plot(Xplot, Yplot)
plt.show()